﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SistemaCartoes.Models;
using SistemaCartoes.Repositorios.Interfaces;

namespace SistemaCartoes.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CartaoController : ControllerBase
    {
        private readonly ICartaoRepository _cartaoRepository;   
        public CartaoController(ICartaoRepository cartaoRepository)
        {
            _cartaoRepository = cartaoRepository;
        }

        [HttpGet]
        public async Task<ActionResult<List<CartaoModel>>> BuscarTodosCartoes()
        {
            List<CartaoModel> cartoes = await _cartaoRepository.BuscarTodosCartoes();
            return Ok(cartoes);
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<CartaoModel>> BuscarCartaoPorId(int id)
        {
            CartaoModel cartoes = await _cartaoRepository.BuscarCartaoPorID(id);
            return Ok(cartoes);
        }

        [HttpPost("AdicionarCartaoProvedorA")]
        public async Task<ActionResult<CartaoModel>> AdicionarCartaoProvedorA([FromBody] CartaoModel cartaoModel)
        {
            CartaoModel cartao = await _cartaoRepository.AdicionarCartaoProvedorA(cartaoModel);
            return Ok(cartao);
        }

        [HttpPost("AdicionarCartaoProvedorB")]
        public async Task<ActionResult<CartaoModel>> AdicionarCartaoProvedorB([FromBody] CartaoModel cartaoModel)
        {
            CartaoModel cartao = await _cartaoRepository.AdicionarCartaoProvedorB(cartaoModel);
            return Ok(cartao);
        }
    }
}
