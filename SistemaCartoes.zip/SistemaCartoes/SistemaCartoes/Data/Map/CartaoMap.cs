﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking.Internal;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using SistemaCartoes.Models;

namespace SistemaCartoes.Data.Map
{
    public class CartaoMap : IEntityTypeConfiguration<CartaoModel>
    {
        public void Configure(EntityTypeBuilder<CartaoModel> builder)
        {
            builder.HasKey(x => x.Id);
            builder.Property(x => x.NumeroCartao).IsRequired();
            builder.Property(x => x.CVV).IsRequired().HasMaxLength(4);
            builder.Property(x => x.Token);
        }
    }
}
