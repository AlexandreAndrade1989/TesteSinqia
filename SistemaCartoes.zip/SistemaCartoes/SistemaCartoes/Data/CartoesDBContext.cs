﻿using Microsoft.EntityFrameworkCore;
using SistemaCartoes.Data.Map;
using SistemaCartoes.Models;

namespace SistemaCartoes.Data
{
    public class CartoesDBContext : DbContext
    {
        public CartoesDBContext(DbContextOptions<CartoesDBContext> options)
            : base(options)
        {
                
        }

        public DbSet<CartaoModel> Cartoes { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.ApplyConfiguration(new CartaoMap());
            base.OnModelCreating(modelBuilder); 
        }
    }
}
