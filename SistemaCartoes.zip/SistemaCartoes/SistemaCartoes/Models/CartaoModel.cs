﻿namespace SistemaCartoes.Models
{
    public class CartaoModel
    {
        public int Id { get; set; } 

        public string NumeroCartao { get; set; }

        public int CVV { get; set; }

        public string Token { get; set; }
    }
}
