﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion.Internal;
using SistemaCartoes.Data;
using SistemaCartoes.Models;
using SistemaCartoes.Repositorios.Interfaces;
using System;
using System.Security.Cryptography;
using System.Text;

namespace SistemaCartoes.Repositorios
{
    public class CartaoRepository : ICartaoRepository
    {
        private readonly CartoesDBContext _dbContext;
        public CartaoRepository(CartoesDBContext cartoesDBContext)
        {
            _dbContext = cartoesDBContext;
        }

        // Busca todos os cartões cadastrados na base.
        public async Task<List<CartaoModel>> BuscarTodosCartoes()
        {
            return await _dbContext.Cartoes.ToListAsync();
        }

        // Busca cartão pelo ID da primary key da tabela "Cartoes" do banco de dados.
        public async Task<CartaoModel> BuscarCartaoPorID(int id)
        {
            return await _dbContext.Cartoes.FirstOrDefaultAsync(x => x.Id == id);
        }

        // Para o Provedor A, retorne um MD5 com hash no número do cartão.
        public async Task<CartaoModel> AdicionarCartaoProvedorA(CartaoModel cartao)
        {
            if (cartao.NumeroCartao == null || cartao.NumeroCartao == "") 
            {
                throw new Exception("O número do cartão não pode ser nulo ou em branco");
            }

            if (cartao.NumeroCartao.Replace("-", "").Replace(" ", "").Length < 16 || cartao.NumeroCartao.Replace("-", "").Replace(" ", "").Length > 16)
            {
                throw new Exception("O número do cartão deve conter 16 números");
            }

            if (cartao.CVV == 0)
            {
                throw new Exception("O número do cartão não pode ser nulo ou em branco");
            }

            if (cartao.CVV.ToString().Length > 4)
            {
                throw new Exception("O número do CVV deve conter até 4 digitos");
            }

            // Realiza a criptografia hasd MD5 do número do cartão.
            cartao.NumeroCartao = CriptografarNumeroCartao(cartao.NumeroCartao);

            // Recebe o token para gravar na tabela "Cartoes" do banco de dados.
            cartao.Token = GerarToken();

            await _dbContext.Cartoes.AddAsync(cartao);
            await _dbContext.SaveChangesAsync();

            return cartao;
        }

        // Para o Provedor B, siga a lógica abaixo:
        
        //O algoritmo usado para criar o token é:
        //a) Obtenha os últimos 4 dígitos do cartão
        //b) Aplique o algoritmo descrito abaixo no Problema nº 1 e o número de rotações seria o número CVV.
        //Problema nº 1
        //A operação chamada rotação circular à direita em um array de inteiros consiste em mover o último
        //elemento da matriz para a primeira posição e deslocando todos os elementos restantes para a direita.Dado um
        //matriz de inteiros, execute a operação de rotação várias vezes.
        //Para cada matriz, execute uma série de rotações circulares para a direita e retorne esta matriz.
        //Por exemplo, matriz a = [3, 4, 5], número de rotações k = 2.
        //Primeiro realizamos as duas rotações:
        //[3, 4, 5] [5, 3, 4] [4, 5, 3]
        //O resultado disso seria[4, 5, 3]
        //Explicação
        //Dado o array[1, 2, 3] após a primeira rotação, o array se torna[3, 1, 2].
        //Após a segunda(e última) rotação, a matriz se torna[2, 3, 1].
        public async Task<CartaoModel> AdicionarCartaoProvedorB(CartaoModel cartao)
        {
            if (cartao.NumeroCartao == null || cartao.NumeroCartao == "")
            {
                throw new Exception("O número do cartão não pode ser nulo ou em branco");
            }

            if (cartao.NumeroCartao.Replace("-", "").Replace(" ", "").Length < 16 || cartao.NumeroCartao.Replace("-", "").Replace(" ", "").Length > 16)
            {
                throw new Exception("O número do cartão deve conter 16 números");
            }

            if (cartao.CVV == 0)
            {
                throw new Exception("O número do cartão não pode ser nulo ou em branco");
            }

            if (cartao.CVV.ToString().Length > 4)
            {
                throw new Exception("O número do CVV deve conter até 4 digitos");
            }

            // Obtém apenas os 4 últimos dígitos do cartão.
            cartao.NumeroCartao = "**** **** **** " + cartao.NumeroCartao.Substring(cartao.NumeroCartao.Length - 4);

            // Separando o CVV dentro de um array de inteiros.
            int[] cvv = Array.ConvertAll(cartao.CVV.ToString().ToArray(), x => (int)x - 48);

            // Realiza as rotações do array CVV
            RotacionarArray(cvv);
            RotacionarArray(cvv);

            // Jogando o resultado das duas rotações para serem gravadas no banco de dados.
            cartao.CVV = cvv.Select((t, i) => t * Convert.ToInt32(Math.Pow(10, cvv.Length - i - 1))).Sum();

            // Recebe o token para gravar na tabela "Cartoes" do banco de dados.
            cartao.Token = GerarToken();

            await _dbContext.Cartoes.AddAsync(cartao);
            await _dbContext.SaveChangesAsync();

            return cartao;
        }

        // Método que realiza a criptogratia do número do cartão.
        public static string CriptografarNumeroCartao(string numeroCartao)
        {
            using (var md5 = new MD5CryptoServiceProvider())
            {
                using (var tdes = new TripleDESCryptoServiceProvider())
                {
                    tdes.Key = md5.ComputeHash(UTF8Encoding.UTF8.GetBytes(numeroCartao));
                    tdes.Mode = CipherMode.ECB;
                    tdes.Padding = PaddingMode.PKCS7;

                    using (var transform = tdes.CreateEncryptor())
                    {
                        byte[] textBytes = UTF8Encoding.UTF8.GetBytes(numeroCartao);
                        byte[] bytes = transform.TransformFinalBlock(textBytes, 0, textBytes.Length);
                        return Convert.ToBase64String(bytes, 0, bytes.Length);
                    }
                }
            }
        }

        // Método para gerar Token.
        public static string GerarToken()
        {
            byte[] time = BitConverter.GetBytes(DateTime.UtcNow.ToBinary());
            byte[] key = Guid.NewGuid().ToByteArray();
            string token = Convert.ToBase64String(time.Concat(key).ToArray());
            return token;
        }

        // Método para rotacionar array colocando o último elemento para a primeira posição.
        public static void RotacionarArray(int[] cvv)
        {
            if (cvv == null || cvv.Length <= 1)
            {
                return;
            }

            int lastElement = cvv[cvv.Length - 1];
            for (int i = cvv.Length - 1; i > 0; i--)
            {
                cvv[i] = cvv[i - 1];
            }
            cvv[0] = lastElement;
        }
    }
}
