﻿using SistemaCartoes.Models;

namespace SistemaCartoes.Repositorios.Interfaces
{
    public interface ICartaoRepository
    {
        Task<List<CartaoModel>> BuscarTodosCartoes();
        Task<CartaoModel> BuscarCartaoPorID(int id);
        Task<CartaoModel> AdicionarCartaoProvedorA(CartaoModel cartao);
        Task<CartaoModel> AdicionarCartaoProvedorB(CartaoModel cartao);
    }
}
